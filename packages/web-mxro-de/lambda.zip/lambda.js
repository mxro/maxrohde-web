"use strict";
var __getOwnPropNames = Object.getOwnPropertyNames;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};

// dist/src/utils/routing/routes-manifest.json
var require_routes_manifest = __commonJS({
  "dist/src/utils/routing/routes-manifest.json"(exports2, module2) {
    module2.exports = {
      version: 3,
      pages404: true,
      basePath: "",
      redirects: [
        {
          source: "/:path+/",
          destination: "/:path+",
          internal: true,
          statusCode: 308,
          regex: "^(?:/((?:[^/]+?)(?:/(?:[^/]+?))*))/$"
        }
      ],
      headers: [],
      dynamicRoutes: [
        {
          page: "/404",
          regex: "^\\/404$"
        },
        {
          page: "/index",
          regex: "^\\/index$"
        }
      ],
      staticRoutes: [
        {
          page: "/",
          regex: "^/(?:/)?$",
          routeKeys: {},
          namedRegex: "^/(?:/)?$"
        }
      ],
      dataRoutes: [],
      rewrites: []
    };
  }
});

// dist/src/utils/routing/lambda.js
var __importDefault = exports && exports.__importDefault || function(mod) {
  return mod && mod.__esModule ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
var routes_manifest_json_1 = __importDefault(require_routes_manifest());
var handler = (event, context, callback) => {
  const request = event.Records[0].cf.request;
  const dynamicRoutes = routes_manifest_json_1.default.dynamicRoutes;
  const extension = request.uri.indexOf(".") !== -1 ? request.uri.split(".").pop() : ".html";
  for (const route of dynamicRoutes) {
    if (new RegExp(route.regex).test(request.uri)) {
      request.uri = route.page + extension;
      break;
    }
  }
  if (request.uri.indexOf(extension) === -1) {
    request.uri = request.uri + extension;
  }
  callback(null, request);
};
exports.handler = handler;
